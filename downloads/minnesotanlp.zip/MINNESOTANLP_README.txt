Minnesota NLP overlay

Overleaf quick start (no clone, Python, or template registration required)

1. Upload your official conference template to Overleaf, or open your existing
   paper project.
2. Unzip this archive locally. In that project, upload minnesotanlp.sty beside
   your main .tex file and upload the logos/ folder with both images inside.
3. Add this as the LAST package in the preamble, before \begin{document}:

    \usepackage{minnesotanlp}

Recompile with your conference template's usual engine. Keep its conference
package, author/title commands, content, and bibliography.
This archive supplies the style and logos to add to an existing paper project.

Use [black] for black text, or [off] to restore the conference format.
Minnesota mode is an author-visible preprint with A4 single-column layout.
Review line numbers are removed, and long shared author rows wrap to fit.
For the official conference camera-ready layout, use [off] and the conference's
final setting (for example, \iclrfinalcopy for ICLR).

Tested templates: ICLR 2027, NeurIPS 2026, the bundled ACL style,
ICML 2025, CVPR 2026, ICCV 2025, and plain article.
Requires a LaTeX distribution from 2021 or newer with standard packages.
